from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/')
def index():
    return render_template("index.html")


@app.route('/', methods=['POST'])
def getdata():
    try:
        from googlesearch import search
    except ImportError:
        print("No module named 'google' found")

        # to search
    query = request.form['search']
    list=[]

    for j in search(query, tld="com", num=10, start=0,stop=None, pause=10):
        list.append(j)

        if '.pdf' in j:

            return render_template('index.html',list = j)

        if '.ppt' in j:
            return render_template('index.html',list = j)

if __name__ == "__main__":
    app.run(debug=True)
